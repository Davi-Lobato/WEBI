# Front

## Colors

### Primary

- Azul claro: hsl (225, 100%, 94%)
- Azul brilhante: hsl (245, 75%, 52%)

### Neutro

- Azul muito claro: hsl(225, 100%, 98%)
- Azul dessaturado: hsl (224, 23%, 55%)
- Azul escuro: hsl (245, 75%, 52%)

## Tipografia

### Cópia do corpo

- Tamanho da fonte (parágrafo): 16px

### Fonte

- Família: [Red Hat Display](https://fonts.google.com/specimen/Red+Hat+Display)
- Pesos: 500, 700, 900